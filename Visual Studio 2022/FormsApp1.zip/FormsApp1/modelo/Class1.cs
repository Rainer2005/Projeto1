﻿namespace modelo
{
    public class Class1
    {

    }
}