﻿using modelo;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormsApp1
{
    public partial class CLIENTE : Form
    {
        public CLIENTE()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cliente_modelo cliente = new cliente_modelo();
            cliente.nome = nome.Text;
            cliente.telefone = numero.Text;
            cliente.endereco = endereco.Text;
            MessageBox.Show("Cliente Salvo com Sucesso");

        }
    }
}
