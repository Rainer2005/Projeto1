﻿namespace controle
{
    public class Class1
    {

    }
}